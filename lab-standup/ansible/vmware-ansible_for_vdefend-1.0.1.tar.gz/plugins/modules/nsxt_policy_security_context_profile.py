#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Copyright 2018 VMware, Inc.
# SPDX-License-Identifier: BSD-2-Clause OR GPL-3.0-only
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: nsxt_context_profiles
short_description: 'Create a new context profile.'
description: "Creates a new context profile using the specified URLs. attributes is a
              required parameter. display_name & description are optional parameters"
version_added: '1.0'
author: 'William Stoneman'
options:
    hostname:
        description: 'Deployed NSX manager hostname.'
        required: true
        type: str
    mgr_type:
        choices:
            - global
            - local
        description: 'If NSX manager is a Global manager or local manager'
                      'global' is used to create or update resource on a Global manager.
                      'absent' is used to create or update resource on a local manager."
        required: true
    username:
        description: 'The username to authenticate with the NSX manager.'
        required: true
        type: str
    password:
        description: 'The password to authenticate with the NSX manager.'
        required: true
        type: str
    attributes:
        description: "Represents the URLs for the context profile."
        required: true
        type: list
    display_name:
        description: 'Display name'
        required: true
        type: str
    description:
        description: 'Description of the resource'
        required: false
        type: str
    state:
        choices:
            - present
            - absent
        description: "State can be either 'present' or 'absent'.
                      'present' is used to create or update resource.
                      'absent' is used to delete resource."
        required: true

'''

EXAMPLES = '''
- name: Create a new Context Profile
  nsxt_security_services:
    hostname: "10.192.167.137"
    mgr_type: local
    username: "admin"
    password: "Admin!23Admin"
    validate_certs: False
    display_name: "IPBlock-Tenant-1"
    description: "IPBlock-Tenant-1 Description"
    attributes:
    - key: DOMAIN_NAME
      datatype: STRING
      value:
      - depot.broadcom.com
      - hostupdate.vmware.com
      - vapp-updates.vmware.com
      - vcsa.vmware.com
      - feedback.esp.vmware.com
      - vcgw-updates.vmware.com
      - partnerweb.vmware.com
      - '*.esp.vmware.com'
      - '*.prod.nsxti.vmware.com'
    state: present
    id: "IPBlock_Tenant_1"
'''

RETURN = '''# '''

import json
import time
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.vmware.ansible_for_nsxt.plugins.module_utils.nsxt_base_resource import NSXTBaseRealizableResource
from ansible_collections.vmware.ansible_for_nsxt.plugins.module_utils.nsxt_resource_urls import SECURITY_POLICY_URL
from ansible_collections.vmware.ansible_for_nsxt.plugins.module_utils.policy_resource_specs.security_policy import SPEC as SecurityPolicySpec
from ansible.module_utils._text import to_native


class NSXTSecurityPolicy(NSXTBaseRealizableResource):
    @staticmethod
    def get_resource_spec():
        return SecurityPolicySpec

    @staticmethod
    def get_resource_base_url(baseline_args):
        return SECURITY_POLICY_URL.format(
            baseline_args["domain_id"])

    def update_resource_params(self, nsx_resource_params):
        nsx_resource_params.pop('domain_id')


if __name__ == '__main__':
    sec_policy = NSXTSecurityPolicy()
    sec_policy.realize(baseline_arg_names=["domain_id"])
