#!/usr/bin/python

# -*- coding: utf-8 -*-


# Copyright 2020 VMware, Inc.
# SPDX-License-Identifier: BSD-2-Clause OR GPL-3.0-only


# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

SPEC = dict(
    app_ids=dict(
        required=False,
        type='list',
        elements='str'
    ),
    attributes=dict(
        required=False,
        type='list',
        elements='dict',
        options=dict(
            attribute_source=dict(
                required=False,
                type='str',
                choices=['APP_ID', 'DOMAIN', 'FQDN', 'URL', 'URL_CATEGORY']
            ),
            attribute_values=dict(
                required=False,
                type='list',
                elements='str'
            ),
            description=dict(
                required=False,
                type='str'
            ),
            display_name=dict(
                type='str'
            ),
            id=dict(
                type='str'
            ),
            sub_attributes=dict(
                required=False,
                type='list',
                elements='dict',
                options=dict(
                    tls_cipher_suite=dict(
                        required=False,
                        type='list',
                        elements='str'
                    ),
                    tls_version=dict(
                        required=False,
                        type='list',
                        elements='str',
                        choices=['SSL_V2', 'SSL_V3', 'TLS_V10', 'TLS_V11', 
                                'TLS_V12', 'TLS_V13']
                    ),
                    cifs_smb_version=dict(
                        required=False,
                        type='list',
                        elements='str'
                    )
                )
            ),
            tags=dict(
                type='list',
                elements='dict',
                options=dict(
                    scope=dict(
                        type='str'
                    ),
                    tag=dict(
                        type='str'
                    )
                )
            )
        )
    ),
    description=dict(
        required=False,
        type='str'
    )
)